/**
 * School Grading App — Google Sheets shared database
 * 1) Create a blank Google Sheet for the school.
 * 2) Extensions > Apps Script; replace Code.gs with this file.
 * 3) Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone
 * 4) Copy the Web app URL ending in /exec into the app on each phone.
 *
 * The sheet stores the app's complete JSON snapshot in a hidden-ish data tab.
 * Do not share the Web App URL publicly; anyone who has it can access this data.
 */
const DATA_SHEET_NAME = 'SchoolAppData';
const DATA_CELL = 'A1';

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'load';
  if (action !== 'load') return json_({ok:false, error:'Unsupported action'});
  try {
    const sheet = getDataSheet_();
    const raw = sheet.getRange(DATA_CELL).getValue();
    if (!raw) return json_({ok:true, data:null, updatedAt:null});
    const record = JSON.parse(String(raw));
    return json_({
      ok:true,
      data:record.data || null,
      updatedAt:record.updatedAt || null,
      updatedBy:record.updatedBy || ''
    });
  } catch (err) {
    return json_({ok:false, error:String(err)});
  }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.action !== 'save' || !body.data) {
      return json_({ok:false, error:'Invalid save request'});
    }
    const sheet = getDataSheet_();
    const record = {
      data:body.data,
      updatedAt:new Date().toISOString(),
      updatedBy:String(body.user || 'Teacher').slice(0,100)
    };
    sheet.getRange(DATA_CELL).setValue(JSON.stringify(record));
    sheet.getRange('A2').setValue('Last updated: ' + record.updatedAt);
    sheet.getRange('A3').setValue('Updated by: ' + record.updatedBy);
    return json_({ok:true, updatedAt:record.updatedAt});
  } catch (err) {
    return json_({ok:false, error:String(err)});
  } finally {
    try { lock.releaseLock(); } catch (ignored) {}
  }
}

function getDataSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Bind this script to the school Google Sheet first.');
  let sh = ss.getSheetByName(DATA_SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(DATA_SHEET_NAME);
    sh.getRange('A1').setNumberFormat('@');
    sh.setColumnWidth(1, 500);
  }
  return sh;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
