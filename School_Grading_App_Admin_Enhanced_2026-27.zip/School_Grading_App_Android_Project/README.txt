SCHOOL GRADING APP - ANDROID PROJECT

This project wraps the reset-password HTML app in an Android WebView.
The HTML file is bundled locally in app/src/main/assets/index.html.

App login password: ASP@1994

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP file.
3. Open the extracted School_Grading_App_Android_Project folder in Android Studio.
4. Allow Gradle sync and install any requested Android SDK components.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

For a shareable release APK:
Build > Generate Signed Bundle / APK > APK, then create or select a signing key.

NOTE
This ZIP is the Android Studio project, not a compiled APK. This environment does not
have the Android SDK/Gradle build tools required to compile the APK binary.


ADMIN ENHANCED BUILD 2026-27
App and administrator password: ASP@1994 (case-sensitive).
Admin tools include full JSON backup, restore, marks/attendance reset, teacher list management, school details, roster editing and student import.
The Google Sheets sync URL is preconfigured. Cloud sync still requires a valid deployed Apps Script endpoint and permissions.
